##########################################################################################
# M""""""""M                   dP          #
# Mmmm  mmmM                   88          #
# MMMM  MMMM .d8888b. .d8888b. 88 .d8888b. #
# MMMM  MMMM 88ooood8 Y8ooooo. 88 88'  `88 #
# MMMM  MMMM 88.  ...       88 88 88.  .88 #
# MMMM  MMMM `88888P' `88888P' dP `88888P8 #
# MMMMMMMMMM                               # Pixel 4 XL (Coral) - June 2020
##########################################################################################

#Print welcome message
ui_print "- Installing, Oneplus7Pro (GM1917) Prop - 2020"
ui_print "- By _Faisal, Telegram: @ZZxzXzxZZZ"